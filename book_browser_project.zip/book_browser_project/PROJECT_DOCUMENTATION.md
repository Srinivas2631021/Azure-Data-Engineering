# Book Browser MVP - Complete Project Documentation

## 1. Executive Summary

Book Browser is a lightweight desktop application developed using Python, Tkinter, and SQLite. The purpose of the project is to provide a practical example of how a Python desktop application can interact with a relational database and execute SQL SELECT queries based on user input.

The MVP provides a simple graphical interface where users can browse book records, search for books, filter records by genre, and clear the applied filters.

The project does not require a separate database server or external Python framework. SQLite stores the data locally in a single database file.

---

## 2. Problem Statement

Users need a simple way to browse and search a collection of books without manually querying a database.

The project solves this by providing:
1. A desktop GUI.
2. A local SQLite database.
3. Search functionality.
4. Genre filtering.
5. SQL SELECT queries based on user input.
6. A tabular display of query results.

---

## 3. Project Objectives

### Primary objectives
- Build a functional Python desktop application.
- Use Tkinter for the graphical user interface.
- Use SQLite as the local relational database.
- Demonstrate SQL SELECT queries.
- Allow users to search book records.
- Allow users to filter books by genre.
- Keep the application lightweight and easy to run.

### Learning objectives
- Understand Python database connectivity.
- Practice SQL WHERE and LIKE clauses.
- Understand parameterized queries.
- Understand CRUD-oriented database architecture, with SELECT implemented in this MVP.
- Practice GUI event handling.
- Separate UI and database responsibilities.

---

## 4. MVP Scope

### Included
- Database initialization.
- Sample book data.
- Book listing.
- Search by title.
- Search by author.
- Search by ISBN.
- Genre filtering.
- Combined search and genre filtering.
- Clear filters.
- Result count.
- Error handling.

### Not included
- Authentication.
- Remote database.
- Online book API.
- Book creation/editing/deletion.
- User accounts.
- Cloud deployment.

These can be added after the MVP.

---

## 5. Functional Requirements

| ID | Requirement | Status |
|---|---|---|
| FR-01 | Application starts from Python | Implemented |
| FR-02 | SQLite database is available locally | Implemented |
| FR-03 | Book records can be displayed | Implemented |
| FR-04 | User can search books | Implemented |
| FR-05 | Search supports title | Implemented |
| FR-06 | Search supports author | Implemented |
| FR-07 | Search supports ISBN | Implemented |
| FR-08 | User can filter by genre | Implemented |
| FR-09 | Search and genre can be combined | Implemented |
| FR-10 | User can clear filters | Implemented |
| FR-11 | SQL SELECT is used for retrieval | Implemented |

---

## 6. Non-Functional Requirements

### Performance
The application is designed for a small local database and should respond quickly for normal MVP-sized datasets.

### Usability
The interface contains clear search, genre, and clear-filter controls.

### Maintainability
GUI logic and database operations are separated into:
- `app.py`
- `database.py`

### Portability
SQLite does not require a database server, making the application easy to move between systems.

---

## 7. Technology Stack

### Python
Python is used for application logic and database interaction.

### Tkinter
Tkinter provides:
- Windows
- Labels
- Entry fields
- Buttons
- Combo boxes
- Tables using Treeview
- Scrollbars

### SQLite
SQLite provides local relational data storage.

### sqlite3
Python's built-in `sqlite3` module is used to:
- Connect to SQLite.
- Execute SQL.
- Retrieve results.
- Commit database changes.
- Close connections.

### SQL
SQL is used for:
- SELECT
- WHERE
- LIKE
- DISTINCT
- ORDER BY

### Git and GitHub
Git tracks source-code changes and GitHub hosts the project repository for submission.

---

## 8. System Architecture

```text
+--------------------------+
|        User              |
+------------+-------------+
             |
             v
+--------------------------+
|       Tkinter GUI        |
| Search / Filter / Clear  |
+------------+-------------+
             |
             v
+--------------------------+
|        app.py            |
| GUI events and display   |
+------------+-------------+
             |
             v
+--------------------------+
|      database.py         |
| DB connection + queries  |
+------------+-------------+
             |
             v
+--------------------------+
|       SQLite             |
|        books.db          |
+------------+-------------+
             |
             v
+--------------------------+
|       Query Results      |
+--------------------------+
```

---

## 9. Component Description

### app.py

Responsible for:
- Creating the Tkinter window.
- Creating GUI controls.
- Handling button events.
- Reading user input.
- Calling database functions.
- Displaying query results.

### database.py

Responsible for:
- SQLite connection.
- Database initialization.
- Sample data.
- SELECT queries.
- Genre retrieval.

### books.db

Local SQLite database containing the `books` table and sample records.

---

## 10. Database Design

### Table: books

| Column | Type | Constraint | Description |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique book ID |
| title | TEXT | NOT NULL | Book title |
| author | TEXT | NOT NULL | Author name |
| genre | TEXT | NULL | Book category |
| year | INTEGER | NULL | Publication year |
| isbn | TEXT | NULL | ISBN number |

### SQL schema

```sql
CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    genre TEXT,
    year INTEGER,
    isbn TEXT
);
```

---

## 11. SQL Queries

### Get all books

```sql
SELECT id, title, author, genre, year, isbn
FROM books
ORDER BY title;
```

### Search

```sql
SELECT id, title, author, genre, year, isbn
FROM books
WHERE
    title LIKE ?
    OR author LIKE ?
    OR isbn LIKE ?
ORDER BY title;
```

### Search with genre

```sql
SELECT id, title, author, genre, year, isbn
FROM books
WHERE
    (title LIKE ? OR author LIKE ? OR isbn LIKE ?)
    AND genre = ?
ORDER BY title;
```

### Get genres

```sql
SELECT DISTINCT genre
FROM books
WHERE genre IS NOT NULL
ORDER BY genre;
```

---

## 12. Parameterized Queries

The project uses:

```python
cursor.execute(query, parameters)
```

instead of building SQL like:

```python
query = "SELECT * FROM books WHERE title = '" + user_input + "'"
```

Parameterized queries are safer because user-provided values are passed separately from the SQL statement.

---

## 13. User Interface

The GUI contains:

### Search box
Allows the user to enter:
- Title
- Author
- ISBN
- Partial text

### Genre dropdown
Allows selection of:
- All
- Programming
- Fiction
- Self Help
- Dystopian
- Classic
- Productivity

### Search button
Executes the appropriate SELECT query.

### Clear button
Removes the search value and resets the genre to `All`.

### Results table
Displays:
- ID
- Title
- Author
- Genre
- Year
- ISBN

### Status
Displays the number of matching books.

---

## 14. Application Workflow

### Startup

1. Python starts `app.py`.
2. `initialize_database()` is called.
3. SQLite opens `books.db`.
4. The `books` table is created if it does not exist.
5. Sample data is inserted if the table is empty.
6. Tkinter creates the application window.
7. Genres are loaded.
8. All books are displayed.

### Search

1. User enters search text.
2. User optionally selects a genre.
3. User clicks Search.
4. `search()` reads the GUI values.
5. `search_books()` executes a parameterized SELECT query.
6. Results are returned.
7. Treeview is refreshed.

### Clear

1. User clicks Clear.
2. Search field is emptied.
3. Genre is changed to All.
4. All books are loaded again.

---

## 15. Error Handling

The application starts inside a `try/except` block.

If an unexpected error occurs, a Tkinter error dialog is displayed.

Example:

```python
try:
    initialize_database()
    root = tk.Tk()
    BookBrowser(root)
    root.mainloop()
except Exception as error:
    messagebox.showerror("Application Error", str(error))
```

---

## 16. Test Strategy

Testing focuses on functional behavior.

### Areas tested
- Application startup.
- Database creation.
- Book display.
- Search.
- Genre filtering.
- Combined filtering.
- Clear operation.
- No-result search.
- Partial search.
- ISBN search.

Detailed test cases are available in `TEST_CASES.md`.

---

## 17. Sample Test Scenarios

### Test 1: Start application
Expected:
- Window opens.
- Book records are visible.

### Test 2: Search Python
Expected:
- Records related to Python are displayed.

### Test 3: Select Programming
Expected:
- Only Programming books are displayed.

### Test 4: Search Data + Programming
Expected:
- Matching Programming records are displayed.

### Test 5: Search unknown value
Expected:
- Table becomes empty.
- Book count becomes 0.
- Application does not crash.

---

## 18. Advantages of SQLite for This MVP

- No database server required.
- No username/password configuration.
- Single database file.
- Easy backup.
- Built into Python.
- Suitable for small applications.
- Easy to distribute with the project.

---

## 19. Limitations

The MVP is intended for a small local dataset.

For a large multi-user application, a server-based relational database such as PostgreSQL or SQL Server may be more appropriate.

The current version also does not implement INSERT, UPDATE, or DELETE operations through the GUI.

---

## 20. Future Enhancements

### Phase 2
- Add book.
- Edit book.
- Delete book.
- Sort table columns.
- Filter by year.

### Phase 3
- Export search results to CSV.
- Add book details window.
- Add pagination.
- Add statistics.

### Phase 4
- Unit tests.
- Application logging.
- Build Windows executable using PyInstaller.
- Add automated GitHub Actions testing.

---

## 21. GitHub Submission

Recommended repository:

```text
book-browser
```

Commands:

```bash
git init
git add .
git commit -m "Initial Book Browser MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/book-browser.git
git push -u origin main
```

Replace `YOUR_USERNAME` with the actual GitHub username.

The final repository URL should be:

```text
https://github.com/YOUR_USERNAME/book-browser
```

Do not submit a placeholder URL. The repository must actually be created and accessible.

---

## 22. Project Deliverables

The completed project contains:

1. `app.py` - GUI application.
2. `database.py` - SQLite and SQL operations.
3. `books.db` - Local database with sample data.
4. `README.md` - Setup and usage documentation.
5. `PROJECT_DOCUMENTATION.md` - Complete technical documentation.
6. `TEST_CASES.md` - Functional test cases.
7. `requirements.txt` - Python dependency information.
8. `.gitignore` - Git exclusions.
9. `docs/database_schema.sql` - Database schema.

---

## 23. Conclusion

The Book Browser MVP demonstrates the integration of Python, Tkinter, SQLite, and SQL in a small desktop application. It provides a practical example of accepting user input, executing parameterized SELECT queries, retrieving database records, and presenting the results through a graphical interface.

The project is intentionally lightweight so it can be easily understood, executed, tested, and uploaded to GitHub.
