import sqlite3

DB_NAME = "books.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


def initialize_database():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            genre TEXT,
            year INTEGER,
            isbn TEXT
        )
    """)

    cursor.execute("SELECT COUNT(*) FROM books")
    count = cursor.fetchone()[0]

    if count == 0:
        books = [
            ("Python Crash Course", "Eric Matthes", "Programming", 2019, "9781593279288"),
            ("Clean Code", "Robert C. Martin", "Programming", 2008, "9780132350884"),
            ("The Alchemist", "Paulo Coelho", "Fiction", 1988, "9780062315007"),
            ("Atomic Habits", "James Clear", "Self Help", 2018, "9780735211292"),
            ("1984", "George Orwell", "Dystopian", 1949, "9780451524935"),
            ("The Great Gatsby", "F. Scott Fitzgerald", "Classic", 1925, "9780743273565"),
            ("Deep Work", "Cal Newport", "Productivity", 2016, "9781455586691"),
            ("Data Science from Scratch", "Joel Grus", "Programming", 2019, "9781492041139"),
            ("The Pragmatic Programmer", "Andrew Hunt", "Programming", 1999, "9780135957059"),
            ("Ikigai", "Hector Garcia", "Self Help", 2016, "9780143130727")
        ]

        cursor.executemany("""
            INSERT INTO books (title, author, genre, year, isbn)
            VALUES (?, ?, ?, ?, ?)
        """, books)

    connection.commit()
    connection.close()


def get_all_books():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT id, title, author, genre, year, isbn
        FROM books
        ORDER BY title
    """)

    books = cursor.fetchall()
    connection.close()
    return books


def search_books(search_text="", genre="All"):
    connection = get_connection()
    cursor = connection.cursor()

    query = """
        SELECT id, title, author, genre, year, isbn
        FROM books
        WHERE (title LIKE ? OR author LIKE ? OR isbn LIKE ?)
    """

    search_pattern = f"%{search_text}%"
    parameters = [search_pattern, search_pattern, search_pattern]

    if genre != "All":
        query += " AND genre = ?"
        parameters.append(genre)

    query += " ORDER BY title"

    cursor.execute(query, parameters)
    books = cursor.fetchall()
    connection.close()
    return books


def get_genres():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT DISTINCT genre
        FROM books
        WHERE genre IS NOT NULL
        ORDER BY genre
    """)

    genres = [row[0] for row in cursor.fetchall()]
    connection.close()
    return genres
