import tkinter as tk
from tkinter import ttk, messagebox

from database import initialize_database, get_all_books, search_books, get_genres


class BookBrowser:
    def __init__(self, root):
        self.root = root
        self.root.title("Book Browser")
        self.root.geometry("950x570")
        self.root.minsize(800, 480)

        self.create_widgets()
        self.load_genres()
        self.load_books()

    def create_widgets(self):
        title_label = ttk.Label(
            self.root,
            text="Book Database Browser",
            font=("Arial", 20, "bold")
        )
        title_label.pack(pady=15)

        filter_frame = ttk.Frame(self.root)
        filter_frame.pack(fill="x", padx=20, pady=10)

        ttk.Label(filter_frame, text="Search:").pack(side="left", padx=(0, 5))

        self.search_entry = ttk.Entry(filter_frame, width=35)
        self.search_entry.pack(side="left", padx=5)
        self.search_entry.bind("<Return>", lambda event: self.search())

        ttk.Label(filter_frame, text="Genre:").pack(side="left", padx=(20, 5))

        self.genre_var = tk.StringVar(value="All")
        self.genre_combo = ttk.Combobox(
            filter_frame,
            textvariable=self.genre_var,
            state="readonly",
            width=18
        )
        self.genre_combo.pack(side="left", padx=5)

        ttk.Button(filter_frame, text="Search", command=self.search).pack(
            side="left", padx=5
        )
        ttk.Button(filter_frame, text="Clear", command=self.clear_filters).pack(
            side="left", padx=5
        )

        table_frame = ttk.Frame(self.root)
        table_frame.pack(fill="both", expand=True, padx=20, pady=10)

        columns = ("id", "title", "author", "genre", "year", "isbn")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")

        headings = {
            "id": "ID",
            "title": "Title",
            "author": "Author",
            "genre": "Genre",
            "year": "Year",
            "isbn": "ISBN",
        }

        widths = {
            "id": 50,
            "title": 220,
            "author": 180,
            "genre": 120,
            "year": 70,
            "isbn": 160,
        }

        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(column, width=widths[column])

        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.status_label = ttk.Label(self.root, text="Books: 0")
        self.status_label.pack(anchor="w", padx=20, pady=5)

    def load_genres(self):
        self.genre_combo["values"] = ["All"] + get_genres()

    def load_books(self, books=None):
        if books is None:
            books = get_all_books()

        for item in self.tree.get_children():
            self.tree.delete(item)

        for book in books:
            self.tree.insert("", "end", values=book)

        self.status_label.config(text=f"Books: {len(books)}")

    def search(self):
        search_text = self.search_entry.get().strip()
        genre = self.genre_var.get()
        books = search_books(search_text, genre)
        self.load_books(books)

    def clear_filters(self):
        self.search_entry.delete(0, tk.END)
        self.genre_var.set("All")
        self.load_books()


def main():
    try:
        initialize_database()
        root = tk.Tk()
        BookBrowser(root)
        root.mainloop()
    except Exception as error:
        messagebox.showerror("Application Error", str(error))


if __name__ == "__main__":
    main()
