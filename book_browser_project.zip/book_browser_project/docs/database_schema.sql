CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    genre TEXT,
    year INTEGER,
    isbn TEXT
);

SELECT id, title, author, genre, year, isbn
FROM books
ORDER BY title;

SELECT DISTINCT genre
FROM books
WHERE genre IS NOT NULL
ORDER BY genre;
