# Book Browser - Test Cases

| ID | Test | Input | Expected Result |
|---|---|---|---|
| TC01 | Application startup | Run `python app.py` | GUI opens successfully |
| TC02 | Display books | No input | All books are displayed |
| TC03 | Search title | `Python` | Matching book records are displayed |
| TC04 | Search author | `George Orwell` | 1984 is displayed |
| TC05 | Search ISBN | `9781593279288` | Python Crash Course is displayed |
| TC06 | Partial search | `Data` | Matching title/author/ISBN records are displayed |
| TC07 | Genre filter | `Programming` | Only Programming books are displayed |
| TC08 | Combined filter | Search `Data`, Genre `Programming` | Matching Programming records are displayed |
| TC09 | Clear filter | Click Clear | All books are displayed again |
| TC10 | No result | `xyz123notfound` | Empty result table; application remains running |
| TC11 | Enter key | Type search and press Enter | Search executes |
| TC12 | Database initialization | Delete `books.db`, run app | Database and sample data are recreated |
| TC13 | GUI resize | Resize window | Table remains usable |
| TC14 | Scroll | More records than visible rows | Vertical scrollbar works |

## Acceptance Criteria

The MVP is considered successful when:

- The application starts without errors.
- SQLite database is created/available.
- Book records can be viewed.
- Search works for title, author, and ISBN.
- Genre filtering works.
- Combined filtering works.
- Clear returns to all books.
- No-result searches do not crash the application.
- Source code and documentation are present in the GitHub repository.
