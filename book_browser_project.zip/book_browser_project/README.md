# Book Browser - Python Tkinter + SQLite

## 1. Project Overview
Book Browser is a lightweight desktop MVP for browsing a local book database. It demonstrates GUI development with Python Tkinter and database interaction with SQLite.

## 2. Objective
The application allows users to:
- View book records
- Search by title, author, or ISBN
- Filter by genre
- Combine search and genre filters
- Clear filters and return to all records

## 3. Technology Stack
| Tool | Purpose |
|---|---|
| Python 3.10+ | Application programming language |
| Tkinter | Desktop GUI |
| SQLite | Local relational database |
| sqlite3 | Python database connectivity |
| SQL | SELECT and filtering queries |
| Git/GitHub | Version control and submission |

No third-party Python packages are required.

## 4. Project Structure
```text
book-browser/
├── app.py
├── database.py
├── books.db
├── requirements.txt
├── README.md
├── PROJECT_DOCUMENTATION.md
├── TEST_CASES.md
├── .gitignore
└── docs/
    └── database_schema.sql
```

## 5. Requirements
- Python 3.10 or newer recommended
- Windows, macOS, or Linux
- Tkinter installed with Python
- Git for GitHub submission

Check Python:
```bash
python --version
```

Test Tkinter:
```bash
python -m tkinter
```

## 6. Installation
Clone the GitHub repository:
```bash
git clone https://github.com/YOUR_USERNAME/book-browser.git
cd book-browser
```

No external package installation is necessary. `sqlite3` and Tkinter are part of the standard Python distribution in typical installations.

## 7. Running the Application
```bash
python app.py
```

The application creates the `books` table if necessary and loads sample data when the table is empty.

## 8. Database
Database file: `books.db`

Table: `books`

Columns:
- id - INTEGER primary key
- title - TEXT, required
- author - TEXT, required
- genre - TEXT
- year - INTEGER
- isbn - TEXT

## 9. SQL Functionality
The MVP performs SELECT queries for:
- All books
- Search by title
- Search by author
- Search by ISBN
- Genre filtering
- Combined search + genre filtering
- Distinct genre retrieval

Search values use parameterized SQL (`?`) rather than string concatenation.

## 10. Application Flow
```text
User
  |
  v
Tkinter GUI
  |
  +--> Search / Genre Filter
  |
  v
database.py
  |
  v
SQLite SELECT query
  |
  v
books.db
  |
  v
Results
  |
  v
Tkinter Treeview
```

## 11. Security / Good Practices
- Parameterized SQL queries are used for user input.
- No destructive SQL is used by the MVP.
- Database connections are closed after operations.
- Database initialization is separated from GUI code.

## 12. Testing
See `TEST_CASES.md` for functional test cases covering startup, display, search, genre filtering, combined filtering, clearing filters, and invalid/no-result searches.

## 13. GitHub Submission
Create a public GitHub repository named `book-browser`.

```bash
git init
git add .
git commit -m "Initial Book Browser MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/book-browser.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

Final submission format:
`https://github.com/YOUR_USERNAME/book-browser`

## 14. Future Enhancements
- Add/edit/delete books
- Sort columns
- Filter by publication year
- Pagination
- Export results to CSV
- Book details window
- Unit tests
- Packaging as an executable
